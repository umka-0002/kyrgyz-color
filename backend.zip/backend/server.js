const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');

const productRoutes = require('./routes/productRoutes')
const authRoutes = require('./routes/authRoutes')
const orderRoutes = require('./routes/orderRoutes')
const cartRoutes = require('./routes/cartRoutes')

// Загрузка переменных окружения из файла .env
dotenv.config();

// Создание приложения Express
const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors()); // Разрешение CORS для взаимодействия фронтенда с бэкендом
app.use(express.json()); // Позволяет Express парсить JSON-запросы

// Подключение маршрутов
app.use('/api/products', productRoutes );
app.use('/api/auth', authRoutes );
app.use('/api/orders',orderRoutes);
app.use('/api/cart',cartRoutes);

// Подключение к базе данных MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}, () => {
  console.log('Connected to MongoDB');
});

// Запуск сервера
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
